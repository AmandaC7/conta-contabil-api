package com.gft.contacontabil;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContaContabilApplicationTests {

	@Test
	void contextLoads() {
	}

}
